/* Placeholder file for database changes for version 2.0.1 to satisfy Joomla!'s extensions installer */
