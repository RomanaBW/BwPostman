ALTER TABLE `#__bwpostman_newsletters` ADD `description` text NOT NULL AFTER `subject`;
