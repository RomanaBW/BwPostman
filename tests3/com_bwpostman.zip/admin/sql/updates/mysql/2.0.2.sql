/* Placeholder file for database changes for version 2.0.2 to satisfy Joomla!'s extensions installer */
